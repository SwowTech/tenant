﻿<?php
declare(strict_types=1);
namespace Plugin\Vendor\FixtureApp;
class ConfigProvider
{
    public function __invoke(): array
    {
        return [];
    }
}
